module FinalProjectBADDBryan {
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.base;
	requires java.sql;
	exports main;
}